package com.cidead.pmdm.tareaut071adivinanumerodediegomanuel;

import androidx.appcompat.app.AppCompatActivity;

import android.app.Activity;
import android.content.Context;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import java.io.BufferedReader;
import java.io.File;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.OutputStreamWriter;
import java.util.Random;
// Diego Manuel Carrasco Castañares
public class MainActivity extends AppCompatActivity implements View.OnClickListener {

    Random random = new Random();
    int numAleatorio = random.nextInt(25) + 1;
    int numAlmacenado;
    int numeroUsuario;
    int numIntentos = 0;
    EditText etNumero;
    TextView tvMostrarPunt, tvResultado;
    Button btEnviar;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        etNumero = (EditText) findViewById(R.id.etNum);
        tvMostrarPunt = (TextView) findViewById(R.id.tvMostrarPunt);
        btEnviar = (Button) findViewById(R.id.btEnviar);
        tvResultado = (TextView) findViewById(R.id.tvResultado);
        btEnviar.setOnClickListener(this);
        SharedPreferences sharedPreferences = getSharedPreferences("Score", Context.MODE_PRIVATE);
        SharedPreferences.Editor editor = sharedPreferences.edit();
        numAlmacenado = sharedPreferences.getInt("Ganado", 0);
        tvMostrarPunt.setText(String.valueOf(numAlmacenado));
    }

    @Override
    public void onClick(View v) {
        SharedPreferences sharedPreferences = getSharedPreferences("Score", Context.MODE_PRIVATE);
        SharedPreferences.Editor editor = sharedPreferences.edit();
        numAlmacenado = sharedPreferences.getInt("Ganado", 0);

        if(etNumero.getText().toString().isEmpty()) {
            Toast.makeText(this, "Debes introducir un número", Toast.LENGTH_LONG).show();
        }else {
            String textoEtNumero = etNumero.getText().toString();
            numeroUsuario = Integer.parseInt(textoEtNumero);
            if (numeroUsuario < numAleatorio) {
                tvResultado.setText("El número oculto es mayor");
            }
            if (numeroUsuario > numAleatorio) {
                tvResultado.setText("El número oculto es menor");
            }
            if (numeroUsuario == numAleatorio) {
                tvResultado.setText("Has adivinado el número");
                numAlmacenado++;
                Toast.makeText(this, "Llevas " + numAlmacenado + " aciertos", Toast.LENGTH_LONG).show();
                Toast.makeText(this, "Has necesitado " + numIntentos +" intentos", Toast.LENGTH_LONG).show();
                editor.putInt("Ganado", numAlmacenado);
                editor.commit();
                OutputStreamWriter archivo = null;

                try {
                    archivo = new OutputStreamWriter(openFileOutput("numSecreto.txt", Activity.MODE_PRIVATE));
                    archivo.write(String.valueOf(numAleatorio));
                    archivo.flush();
                    archivo.close();
                    File fichero = new File("/data/data/com.example.tareaut071/files/numSecreto.txt");
                    InputStreamReader archivoRecivido = new InputStreamReader(openFileInput(fichero.getName()));
                    BufferedReader br = new BufferedReader(archivoRecivido);
                    String linea = br.readLine();
                    Toast.makeText(this, "El número secreto es " + linea, Toast.LENGTH_LONG).show();
                    numAleatorio = random.nextInt(25) + 1;

                } catch (IOException e) {
                    throw new RuntimeException(e);
                }
            }
            numIntentos++;
            etNumero.setText("");

        }
    }
}